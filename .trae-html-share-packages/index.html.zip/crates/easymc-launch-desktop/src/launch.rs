use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::Arc;

use easymc_core::{Account, AccountKind, EasyMcError, Instance, ModLoader, Paths, Result, Settings};
use easymc_meta::rules_allow;
use easymc_meta::{
    classpath_jars, extract_natives, fabric_profile_id, forge_profile_id, is_version_installed,
    load_installed_version, neoforge_profile_id, quilt_profile_id, VersionInfo,
};
use serde_json::Value;

use crate::java::{ensure_java, select_java, JavaInstall};
use crate::process::{LaunchStatus, ProcessManager};

#[derive(Debug, Clone)]
pub struct LaunchRequest {
    pub extra_jvm_args: Vec<String>,
    pub memory_mb: u32,
}

impl Default for LaunchRequest {
    fn default() -> Self {
        Self {
            extra_jvm_args: vec![],
            memory_mb: 2048,
        }
    }
}

/// Resolve the version JSON id to launch for this instance (vanilla or loader profile).
pub fn resolve_launch_version(paths: &Paths, instance: &Instance) -> Result<VersionInfo> {
    let id = match instance.loader {
        ModLoader::Vanilla => instance.version.0.clone(),
        ModLoader::Fabric => {
            let loader_ver = instance.loader_version.as_deref().ok_or_else(|| {
                EasyMcError::msg("Fabric 实例缺少 loader_version，请重新安装 Fabric")
            })?;
            fabric_profile_id(instance.version.as_str(), loader_ver)
        }
        ModLoader::Quilt => {
            let loader_ver = instance.loader_version.as_deref().ok_or_else(|| {
                EasyMcError::msg("Quilt 实例缺少 loader_version，请重新安装 Quilt")
            })?;
            quilt_profile_id(instance.version.as_str(), loader_ver)
        }
        ModLoader::Forge => {
            let loader_ver = instance.loader_version.as_deref().ok_or_else(|| {
                EasyMcError::msg("Forge 实例缺少 loader_version，请重新安装 Forge")
            })?;
            forge_profile_id(instance.version.as_str(), loader_ver)
        }
        ModLoader::NeoForge => {
            let loader_ver = instance.loader_version.as_deref().ok_or_else(|| {
                EasyMcError::msg("NeoForge 实例缺少 loader_version，请重新安装 NeoForge")
            })?;
            neoforge_profile_id(loader_ver)
        }
    };
    if !is_version_installed(paths, &id) {
        // Fall back: vanilla id check message
        if instance.loader == ModLoader::Vanilla {
            return Err(EasyMcError::msg(format!(
                "版本 {} 尚未安装，请先安装",
                instance.version
            )));
        }
        return Err(EasyMcError::msg(format!(
            "加载器配置 {} 尚未安装，请先安装 {} {}",
            id,
            instance.loader.label_zh(),
            instance.version
        )));
    }
    load_installed_version(paths, &id)
}

pub async fn prepare_and_launch(
    paths: &Paths,
    instance: &Instance,
    account: &Account,
    settings: &Settings,
    req: &LaunchRequest,
    procs: Arc<ProcessManager>,
    on_log: impl Fn(String) + Send + Sync + 'static,
) -> Result<LaunchStatus> {
    let info = resolve_launch_version(paths, instance)?;
    // Ensure natives extracted (always from the jar / parent version)
    let natives = paths.natives_for_version(info.jar_id());
    if !natives.exists() || std::fs::read_dir(&natives).map(|mut d| d.next().is_none()).unwrap_or(true)
    {
        on_log("解压 natives…".into());
        extract_natives(paths, &info)?;
    }

    let required = info
        .java_version
        .as_ref()
        .map(|j| j.major_version)
        .unwrap_or(21);
    let preferred = instance
        .java_path
        .as_ref()
        .filter(|s| !s.trim().is_empty())
        .or(settings.preferred_java.as_ref())
        .map(PathBuf::from);
    let java = match select_java(required, preferred.as_deref()) {
        Ok(j) => j,
        Err(_) => {
            on_log(format!("未找到 Java {required}+，尝试下载 Temurin…"));
            ensure_java(paths, required, |s| on_log(s)).await?
        }
    };
    on_log(format!("使用 Java {}: {}", java.major, java.path.display()));

    let args = build_jvm_and_game_args(paths, &info, instance, account, &java, req)?;
    std::fs::create_dir_all(&instance.game_dir)?;

    procs
        .spawn(
            instance.id.clone(),
            java.path.clone(),
            args,
            Path::new(&instance.game_dir),
            HashMap::new(),
            on_log,
        )
        .await
}

pub fn build_jvm_and_game_args(
    paths: &Paths,
    info: &VersionInfo,
    instance: &Instance,
    account: &Account,
    java: &JavaInstall,
    req: &LaunchRequest,
) -> Result<Vec<String>> {
    let _ = java;
    let natives = paths.natives_for_version(info.jar_id());
    let jars = classpath_jars(paths, info)?;
    let sep = if cfg!(windows) { ";" } else { ":" };
    let classpath = jars
        .iter()
        .map(|p| p.to_string_lossy().into_owned())
        .collect::<Vec<_>>()
        .join(sep);

    let mut vars: HashMap<String, String> = HashMap::new();
    vars.insert(
        "natives_directory".into(),
        natives.to_string_lossy().into_owned(),
    );
    vars.insert("launcher_name".into(), "EasyMC".into());
    vars.insert("launcher_version".into(), env!("CARGO_PKG_VERSION").into());
    vars.insert("classpath".into(), classpath.clone());
    vars.insert(
        "auth_player_name".into(),
        account.username.clone(),
    );
    vars.insert("version_name".into(), info.id.clone());
    vars.insert("game_directory".into(), instance.game_dir.clone());
    vars.insert(
        "assets_root".into(),
        paths.assets_dir().to_string_lossy().into_owned(),
    );
    let assets_index = info
        .asset_index
        .as_ref()
        .map(|a| a.id.clone())
        .ok_or_else(|| EasyMcError::msg(format!("版本 {} 缺少 assetIndex", info.id)))?;
    vars.insert("assets_index_name".into(), assets_index);
    vars.insert("auth_uuid".into(), account.uuid.clone());
    vars.insert("auth_access_token".into(), account.access_token.clone());
    vars.insert("clientid".into(), "easymc".into());
    vars.insert("auth_xuid".into(), "0".into());
    let user_type = match account.kind {
        AccountKind::Offline => "legacy",
        AccountKind::Microsoft => "msa",
    };
    vars.insert("user_type".into(), user_type.into());
    vars.insert("version_type".into(), info.version_type.clone());
    vars.insert("library_directory".into(), paths.libraries_dir().to_string_lossy().into_owned());
    vars.insert("classpath_separator".into(), sep.into());

    let mut args = Vec::new();
    let mem = instance.memory_mb.filter(|m| *m >= 512).unwrap_or(req.memory_mb);
    args.push(format!("-Xms{}M", mem.min(1024)));
    args.push(format!("-Xmx{}M", mem));
    args.extend(req.extra_jvm_args.iter().cloned());
    if let Some(extra) = instance.jvm_args.as_deref() {
        args.extend(extra.split_whitespace().map(String::from));
    }

    if let Some(arguments) = &info.arguments {
        for item in &arguments.jvm {
            push_arg_value(&mut args, item, &vars, &[])?;
        }
    } else {
        // Legacy
        args.push(format!("-Djava.library.path={}", natives.display()));
        args.push("-cp".into());
        args.push(classpath);
    }

    args.push(info.main_class.clone());

    if let Some(arguments) = &info.arguments {
        for item in &arguments.game {
            // Skip demo / custom resolution feature flags by default
            push_arg_value(
                &mut args,
                item,
                &vars,
                &[("is_demo_user", false), ("has_custom_resolution", false)],
            )?;
        }
    } else if let Some(legacy) = &info.minecraft_arguments {
        for token in legacy.split_whitespace() {
            args.push(substitute(token, &vars));
        }
    } else {
        return Err(EasyMcError::msg("version json has no arguments"));
    }
    if let (Some(w), Some(h)) = (instance.width, instance.height) {
        if w > 0 && h > 0 {
            args.extend(["--width".into(), w.to_string(), "--height".into(), h.to_string()]);
        }
    }

    Ok(args)
}

fn push_arg_value(
    out: &mut Vec<String>,
    value: &Value,
    vars: &HashMap<String, String>,
    features: &[(&str, bool)],
) -> Result<()> {
    match value {
        Value::String(s) => {
            out.push(substitute(s, vars));
        }
        Value::Object(map) => {
            let rules = map.get("rules").and_then(|r| {
                serde_json::from_value::<Vec<easymc_meta::Rule>>(r.clone()).ok()
            });
            if !rules_allow(rules.as_deref(), features) {
                return Ok(());
            }
            match map.get("value") {
                Some(Value::String(s)) => out.push(substitute(s, vars)),
                Some(Value::Array(arr)) => {
                    for v in arr {
                        if let Value::String(s) = v {
                            out.push(substitute(s, vars));
                        }
                    }
                }
                _ => {}
            }
        }
        _ => {}
    }
    Ok(())
}

fn substitute(template: &str, vars: &HashMap<String, String>) -> String {
    let mut out = template.to_string();
    for (k, v) in vars {
        out = out.replace(&format!("${{{k}}}"), v);
    }
    out
}

/// HMCL-style 「生成启动脚本」: write a shell / batch script that launches this instance
/// without the launcher. The access token is redacted (offline-style "0") so the file never
/// carries a secret; 正版 servers need launching from EasyMC.
pub fn write_launch_script(
    paths: &Paths,
    instance: &Instance,
    account: &Account,
    settings: &Settings,
    req: &LaunchRequest,
) -> Result<PathBuf> {
    let info = resolve_launch_version(paths, instance)?;
    let required = info.java_version.as_ref().map(|j| j.major_version).unwrap_or(21);
    let preferred = instance
        .java_path
        .as_ref()
        .filter(|s| !s.trim().is_empty())
        .or(settings.preferred_java.as_ref())
        .map(PathBuf::from);
    let java = select_java(required, preferred.as_deref())
        .map_err(|_| EasyMcError::msg(format!("还没有 Java {required}，先启动一次游戏让 EasyMC 自动准备")))?;
    let mut safe = account.clone();
    safe.access_token = "0".into();
    let args = build_jvm_and_game_args(paths, &info, instance, &safe, &java, req)?;
    let win = cfg!(windows);
    let quote = |s: &str| {
        if win {
            format!("\"{}\"", s.replace('"', "\\\""))
        } else {
            format!("'{}'", s.replace('\'', "'\\''"))
        }
    };
    let mut body = String::new();
    if win {
        body.push_str("@echo off\r\n");
        body.push_str(&format!("cd /d {}\r\n", quote(&instance.game_dir)));
    } else {
        body.push_str("#!/bin/sh\n# EasyMC 生成的启动脚本\n");
        body.push_str(&format!("cd {} || exit 1\n", quote(&instance.game_dir)));
    }
    body.push_str(&quote(&java.path.to_string_lossy()));
    for a in &args {
        body.push(' ');
        body.push_str(&quote(a));
    }
    body.push_str(if win { "\r\n" } else { "\n" });
    let out = PathBuf::from(&instance.game_dir).join(if win { "launch.bat" } else { "launch.sh" });
    std::fs::write(&out, body)?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let _ = std::fs::set_permissions(&out, std::fs::Permissions::from_mode(0o755));
    }
    Ok(out)
}
